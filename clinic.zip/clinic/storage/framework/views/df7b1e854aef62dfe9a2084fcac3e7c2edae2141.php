
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>client</title>
</head>
<body>
<h1>hi iam client</h1>
    <select name="#" id="select" onclick="load()">

    <option value="0" disabled> select doctor

    </option>

    </select>
</body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    function load(){    $.ajax(
    {
        type:'get',
        url:'/test/ajax',
        dataType:'Json',
        data:{},
        success:function(data){
            $("#select").html('');
            for ( var i=0; i<data['message'].length; i++)
            {
                $("#select").append(`<option value="${data['message'][i]['id']}">${data['message'][i]['name']}</option>`);
            }
                console.log(data);

        }

    }
)};
   $( document ).ready(function() {
    $.ajax(
    {
        type:'get',
        url:'/test/ajax',
        dataType:'Json',
        data:{},
        success:function(data){
            for ( var i=0; i<data['message'].length; i++)
            {
                $("#select").append(`<option value="${data['message'][i]['id']}">${data['message'][i]['name']}</option>`);
            }
                console.log(data);

        }



    }
)
});
</script>
<?php /**PATH C:\Users\DELL\Desktop\project\clinic\resources\views/test.blade.php ENDPATH**/ ?>